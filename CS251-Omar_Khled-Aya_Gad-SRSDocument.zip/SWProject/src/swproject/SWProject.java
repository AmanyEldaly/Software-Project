
package swproject;

import java.io.IOException;

public class SWProject {
    
    public static void main(String[] args) throws IOException 
    {
         
      Controller contol = new Controller();
      contol.Registeration();
   
                
    }
    
}
